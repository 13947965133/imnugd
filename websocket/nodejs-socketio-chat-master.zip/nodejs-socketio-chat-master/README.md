This is a simple chat demo by using Node.js and Socket.IO.


##Online demo:##
  [http://demo.plhwin.com/chat/](http://demo.plhwin.com/chat/)



##Installation tutorial:##
  [http://www.plhwin.com/2014/05/28/nodejs-socketio/](http://www.plhwin.com/2014/05/28/nodejs-socketio/)
